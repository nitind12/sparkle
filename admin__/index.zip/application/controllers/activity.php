<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Activity extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    function index(){
    	$data['user___'] = $this->session->userdata('ussr_');
        $data['activity_'] = $this->mm->get_active_newsletter();
        $data['activity_d'] = $this->mm->get_deactive_newsletter();
        $data['folder_'] = 'activities';
        $data['page__'] = 'feedactivity';
        $data['page_head'] = 'Upload &amp; Manage Activities';
        $data['view1'] = 'viewactivities_active';
        $data['view2'] = 'viewactivities_deactive';

        $this->load->view('templates/header');
        $this->load->view('inner', $data);
        $this->load->view('templates/footer');
    }
    function feedactivity(){
    	
    }
}