<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                &copy; 2016 <a target="_blank" href="#" title="Little Sparkle School">Little Sparkle School</a>. All Rights Reserved.
            </div>
            <div class="col-sm-3">
                Developed by <a target="_blank" href="http://www.teamfreelancers.com" target='_blank' title="Little Sparkle School">Teamfreelancers</a>
            </div>
            <div class="col-sm-5">
                <ul class="pull-right">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Admissions</a></li>
                    <li><a href="#">Features</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer><!--/#footer-->
</body>
</html>