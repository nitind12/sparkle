<div id="team" class="team">
				<div class="container">
					<div class="header team-head text-center">
						<h2>Quick Links</h2>
						<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
					</div>
					<!--- teammember-grids ---->
					<div class="team-member-grids">
						<div class="team-member-grid">
							<img src="<?php echo base_url('_assets_/images/t1.jpg');?>" title="name" />
							<div class="team-member-info bottom-t-info">
								<span> </span>
								<h3><a href="#">Director's Message</a></h3>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type Lorem Ipsum is simply dummy text.is simply dummy text..is simply dummy text.</p>
							</div>
						</div>
						<div class="team-member-grid">
							<div class="team-member-info bottom-t-info bottom-t-info-b">
								<span> </span>
								<h3><a href="#">Principal's Message</a></h3>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type Lorem Ipsum is simply dummy text.is simply dummy text..is simply dummy text..is simply dummy text.</p>
							</div>
							<img src="<?php echo base_url('_assets_/images/t2.jpg');?>" title="name" />
						</div>
						<div class="team-member-grid">
							<img src="<?php echo base_url('_assets_/images/t3.jpg');?>" title="name" />
							<div class="team-member-info bottom-t-info">
								<span> </span>
								<h3><a href="#">Happy Birthday</a></h3>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type Lorem Ipsum is simply dummy text.is simply dummy text..is simply dummy text.</p>
							</div>
						</div>
						<div class="team-member-grid">
							<div class="team-member-info bottom-t-info bottom-t-info-b">
								<span> </span>
								<h3><a href="#">Important Links</a></h3>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type Lorem Ipsum is simply dummy text.is simply dummy text..is simply dummy text..is simply dummy text.</p>
							</div>
							<img src="<?php echo base_url('_assets_/images/t4.jpg');?>" title="name" />
						</div>
						<div class="team-member-grid">
							<img src="<?php echo base_url('_assets_/images/t5.jpg');?>" title="name" />
							<div class="team-member-info bottom-t-info">
								<span> </span>
								<h3><a href="#">PhotoGallery</a></h3>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type Lorem Ipsum is simply dummy text.is simply dummy text..is simply dummy text.</p>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
					<!---//teammember-grids ---->
				</div>
			</div>