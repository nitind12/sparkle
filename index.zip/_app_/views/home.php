
			<?php $this -> load -> view ('templates/slider'); ?>
			
			
			<?php $this -> load -> view('about/index'); ?>
			<?php $this -> load -> view ('team/index'); ?>