
			<div id="services" class="services">
				<div class="container">
					<div class="header services-header text-center">
						<h2>our services</h2>
						<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
					</div>
					<div class="service-grids">
						<div class="col-md-3">
							<div class="service-grid text-center">
								<a href="#"><span class="s1-icon"> </span></a>
								<h3><a href="#">Heart problem</a></h3>
							</div>
						</div>
						<div class="col-md-3">
							<div class="service-grid text-center">
								<a href="#"><span class="s2-icon"> </span></a>
								<h3><a href="#">brain problem</a></h3>
							</div>
						</div>
						<div class="col-md-3">
							<div class="service-grid text-center">
								<a href="#"><span class="s3-icon"> </span></a>
								<h3><a href="#">knee problem</a></h3>
							</div>
						</div>
						<div class="col-md-3">
							<div class="service-grid text-center">
								<a href="#"><span class="s4-icon"> </span></a>
								<h3><a href="#">human bones problem</a></h3>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
